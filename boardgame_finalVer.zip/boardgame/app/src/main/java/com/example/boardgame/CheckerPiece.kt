package com.example.boardgame

 data class CheckerPiece(var col: Int, var row: Int, var player: Player, var imageId: Int) {

}

