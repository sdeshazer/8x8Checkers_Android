package com.example.boardgame


enum class Player{
    RED,
    BLACK,

}
