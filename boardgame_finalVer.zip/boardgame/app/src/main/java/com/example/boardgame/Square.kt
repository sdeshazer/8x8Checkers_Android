package com.example.boardgame


data class Square(val col: Int, val row: Int){

}
