package com.example.boardgame



    data class DarkSquares internal constructor(var col: Int, var row : Int){

    }


